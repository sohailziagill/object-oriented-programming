#include<iostream>
using namespace std;

int
main ()
{
  int size = 3;
  int array[size][size], i, j, sum = 0;
  cout << "Enter nine elements   ";
  for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 3; j++)
	{
	  cin >> array[i][j];
	}
    }

  cout << "\nThe entered elements are \n";
  for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 3; j++)
	{
	  cout << "   " << array[i][j];
	  sum = sum + array[i][j];



	}
      cout <<"   " << sum;
      cout << "\n";
      sum = 0;


    }
  system ("pause");
  return 0;





}
